#pragma once
#define VERSION_MAJOR 1
#define VERSION_MINOR 0
#define VERSION_BUILD 168

#define stringify(a) stringify_(a)
#define stringify_(a) #a

